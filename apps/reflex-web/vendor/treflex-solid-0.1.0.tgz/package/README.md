# treflex-solid

The Solid bindings for [treflex](https://github.com/Tgoh/treflex/blob/HEAD/packages/core/README.md): `TreflexProvider`, features, and the hooks a view reads the runtime through.

```
npm install treflex treflex-solid solid-js
```

[Views](https://github.com/Tgoh/treflex/blob/HEAD/docs/guide/03-views.md) in the guide builds the first view, and the [views reference](https://github.com/Tgoh/treflex/blob/HEAD/docs/reference/views.md) holds every rule.
